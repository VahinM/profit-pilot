# ProfitPilot

AI-powered bookkeeping for small local businesses. One plan, $20/month, everything included.

**Status:** interactive front-end prototype with mock data. No backend, database, or real AI yet — that's the next phase (Supabase + Stripe + OpenAI).

## What's inside

- Dashboard with KPI cards and charts
- Revenue tracking (invoice payments, POS imports, manual entry)
- Expense tracking with search and categories
- Invoices with status tracking
- Customers
- Reports
- AI Advisor (demo responses)
- Billing ($20/mo single plan)
- Settings

## Tech

- React 18 + Vite
- Tailwind CSS
- Recharts (charts)
- Lucide (icons)

## Run it locally

You need [Node.js](https://nodejs.org) installed (version 18 or newer).

```bash
npm install
npm run dev
```

Then open the URL it prints (usually http://localhost:5173).

## Build for production

```bash
npm run build
```

Output goes to `dist/`. Deploys directly to Vercel or Netlify with zero config — just import the repo and both will detect Vite automatically.

## Project structure

```
profitpilot/
├── index.html          # page shell, loads fonts
├── package.json        # dependencies and scripts
├── vite.config.js      # build tool config
├── tailwind.config.js  # styling config
├── postcss.config.js
└── src/
    ├── main.jsx        # entry point
    ├── index.css       # Tailwind + base styles
    └── App.jsx         # the entire app (all pages + mock data)
```

## Next steps (planned)

- Supabase: auth + Postgres database with row-level security
- Stripe: real $20/mo subscription billing
- OpenAI: AI Advisor answering from real ledger data
- Plaid / Square: automatic bank and POS imports
- Receipt scanning (OCR)
- PDF invoice generation
