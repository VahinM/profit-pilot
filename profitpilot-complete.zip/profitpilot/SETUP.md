# Milestone 1: Database + Authentication setup

Follow these steps in order. Takes about 15 minutes. Everything is free.

## Step 1 — Create your Supabase project (5 min)

1. Go to https://supabase.com and sign up (you can use your GitHub account).
2. Click "New project."
3. Name it `profitpilot`, set a strong database password (save it somewhere), pick the region closest to you, and click "Create new project."
4. Wait a minute or two while it provisions.

## Step 2 — Create the database tables (2 min)

1. In your Supabase project, click "SQL Editor" in the left sidebar.
2. Click "New query."
3. Open the file `supabase/schema.sql` from this folder, copy ALL of it, paste it in, and click "Run."
4. You should see "Success. No rows returned." That's correct — it created 6 tables, security rules, and a trigger that automatically creates a business record whenever someone signs up.

## Step 3 — Get your API keys (1 min)

1. In Supabase, click the gear icon (Project Settings) -> "API."
2. You need two values:
   - Project URL (looks like https://abcdefgh.supabase.co)
   - anon public key (a long string under "Project API keys")
3. The anon key is safe to use in a website — the row-level security rules in the schema are what actually protect the data.

## Step 4 — Add the new files to your project (3 min)

Copy these from this folder into your profitpilot project, replacing when asked:

```
src/App.jsx          -> replaces src/App.jsx  (adds sign-out button + shows your email)
src/main.jsx         -> replaces src/main.jsx (now starts at Root instead of App)
src/Root.jsx         -> new (decides: show login screen or the app)
src/Auth.jsx         -> new (login / signup / reset password screens)
src/lib/supabase.js  -> new (the database connection)
supabase/schema.sql  -> new (keep it in the repo for reference)
.env.example         -> new
```

## Step 5 — Add your keys (2 min)

1. In your project folder, copy `.env.example` to a new file named exactly `.env`
2. Fill in the two values from Step 3.
3. IMPORTANT: `.env` must never be uploaded to GitHub. Your `.gitignore` already excludes it — leave that alone.

## Step 6 — Install and run (2 min)

In a terminal inside your project folder:

```bash
npm install @supabase/supabase-js
npm run dev
```

Open the localhost link. You should see the ProfitPilot login screen.
Click "Create an account," sign up with your real email, click the
confirmation link Supabase emails you, then log in.

## What you have now

- Real sign up / log in / password reset
- A database with businesses, customers, invoices, income, and expenses tables
- Row-level security: even with the same database, no user can ever read
  another user's rows — enforced by the database itself, not just the app
- A business record auto-created for every new signup

## What's still mock

The pages inside the app still show demo data. The next milestone wires the
Revenue and Expenses pages to actually read/write these database tables.

## If you deploy to Vercel

Add the same two environment variables in Vercel:
Project -> Settings -> Environment Variables ->
`VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`.
